package net.codejava.swing.combobox;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

public class Main extends JFrame {

	private JButton buttonSelect = new JButton("Select");
//	private JButton buttonRemove = new JButton("Remove");

	public Main() {
		super("Temples");

		setLayout(new FlowLayout(FlowLayout.LEFT, 10, 10));

		String[] bookTitles = new String[] { "Temple 1",
				"Temple 2", "Temple 3" };

		// create a combo box with items specified in the String array:
		final JComboBox<String> templeList = new JComboBox<String>(bookTitles);

		// add more books
		templeList.addItem("Temple 4");
		templeList.addItem("Temple 5");
		templeList.addItem("Temple 6");

		// customize some appearance:
		templeList.setForeground(Color.BLUE);
		templeList.setFont(new Font("Arial", Font.BOLD, 14));
		templeList.setMaximumRowCount(10);
		
		// make the combo box editable so we can add new item when needed
		templeList.setEditable(true);

		// add an event listener for the combo box
		templeList.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent event) {
				JComboBox<String> combo = (JComboBox<String>) event.getSource();
				String selectedBook = (String) combo.getSelectedItem();

				DefaultComboBoxModel<String> model = (DefaultComboBoxModel<String>) combo
						.getModel();

				int selectedIndex = model.getIndexOf(selectedBook);
				if (selectedIndex < 0) {
					// if the selected book does not exist before, 
					// add it into this combo box
					model.addElement(selectedBook);
				}

			}
		});

		// add event listener for the button Select 
		buttonSelect.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				String selectedTemple = (String) templeList.getSelectedItem();
				JOptionPane.showMessageDialog(Main.this,
						"You selected the temple: " + selectedTemple);
			}
		});

		// add event listener for the button Remove
		//buttonRemove.addActionListener(new ActionListener() {
			//@Override
			//public void actionPerformed(ActionEvent event) {
				//String selectedBook = (String) templeList.getSelectedItem();
				//templeList.removeItem(selectedBook);
		//	}
	//	});

		// add components to this frame
		add(templeList);
		add(buttonSelect);
		//add(buttonRemove);

		pack();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
	}

	public static void main(String[] args) {
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		SwingUtilities.invokeLater(new Runnable() {

			@Override
			public void run() {
				new Main().setVisible(true);
			}
		});
	}
}